/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package connect4;
//import static Connect4.g1status;
//import static Connect4.g1status;
//import static Connect4.g2status;
//import static Connect4.g2status;
//import static Connect4.turn;
//import static Connect4.turn;
//import static Connect4.turn;
import java.awt.Color;

/**
 *
 * @author pc
 */
public class connectt4 extends javax.swing.JFrame {
     //groupstatus
    
    public static int turn=1,g1status=1,g2status=1,g3status=1,g4status=1,g5status=1,g6status=1;
    //row status
    
    public int r1status=1,r2status=1,r3status=1,r4status=1,r5status=1,r6status=1;
    //diagonal status
    
      public int d1status=1,d2status=1,d3status=1,d4status=1,d5status=1,d6status=1,d7status=1,d8status=1;
      

 public  void switchturn(){
     if(turn==1)
     { turn=2; jLabel1.setText("Player 2 Turn");}
     else { turn=1; jLabel1.setText("Player 1 Turn");}
  }
 
 //Vertically:
 
 public int groupcheck(int group){
     if(group==1)
         return g1status; 
     else if (group==2) 
         return g2status;
     else if (group==3) 
         return g3status;
     else if (group==4)
         return g4status;
     else if (group==5) 
         return g5status;
          else if (group==6) 
              return g6status;
     else 
              return 0;
      }
 

 //Horizontally:
 
 public int rowscheck(int row){
    if(row==1)
        return r1status;
     else if(row==2)
         return r2status;
    else if(row==3)
        return r3status;
    else if(row==4)
        return r4status;
    else if(row==5)
        return r5status;
    else if(row==6)
        return r6status;
    else return 0;
    
}

 //Diagonally:
 public int diagonalcheck(int diagonal){
    if(diagonal==1)
        return d1status;
     else if(diagonal==2)
         return d2status;
    else if(diagonal==3) 
        return d3status;
    else if(diagonal==4)
        return d4status;
    else if(diagonal==5) 
        return d5status;
    else if(diagonal==6)
        return d6status;
    else if(diagonal==7)
        return d7status;
    else if(diagonal==8) 
        return d8status;
    else return 0;
    
}
    /**
     * Creates new form connectt4
     */
    public connectt4() {
        initComponents();
      
    } 
    
    //horizontally:
  public void checkWinRow(){
      
  //group1:
    String a=g1b1.getBackground().toString();
    String b=g1b2.getBackground().toString();
    String c=g1b3.getBackground().toString();
    String d=g1b4.getBackground().toString();
    String e=g1b5.getBackground().toString();
    String f=g1b6.getBackground().toString();
    
    //group 2
    String g=g2b1.getBackground().toString();
    String h=g2b2.getBackground().toString();
    String i=g2b3.getBackground().toString();
    String j=g2b4.getBackground().toString();
    String k=g2b5.getBackground().toString();
    String l=g2b6.getBackground().toString();
    
    //group 3
    String m=g3b1.getBackground().toString();
    String n=g3b2.getBackground().toString();
    String o=g3b3.getBackground().toString();
    String p=g3b4.getBackground().toString();
    String q=g3b5.getBackground().toString();
    String r=g3b6.getBackground().toString();
    
    //group 4
    String s=g4b1.getBackground().toString();
    String t=g4b2.getBackground().toString();
    String u=g4b3.getBackground().toString();
    String v=g4b4.getBackground().toString();
    String w=g4b5.getBackground().toString();
    String x=g4b6.getBackground().toString();
    
    //group 5
    String y=g5b1.getBackground().toString();
    String z=g5b2.getBackground().toString();
    String g5_b3=g5b3.getBackground().toString();
    String g5_b4=g5b4.getBackground().toString();
    String g5_b5=g5b5.getBackground().toString();
    String g5_b6=g5b6.getBackground().toString();
    
    if(r1status>=4){
       if(a.equals(g)&&g.equals(m)&&m.equals(s)){
            jLabel3.setText("Player" +turn+ "Won");
            DisableButton();
            
        } 
       else if(g.equals(m)&&m.equals(s)&&s.equals(y)){
            jLabel3.setText("Player" +turn+ "Won");
                        DisableButton();
            
       } 
    } 
       if(r2status>=4) {
           if(b.equals(h)&&h.equals(n)&&n.equals(t)){
            jLabel3.setText("Player" +turn+ "Won");
                        DisableButton();
            
        } 
       else if(h.equals(n)&&n.equals(t)&&t.equals(z)){
            jLabel3.setText("Player" +turn+ "Won");
                        DisableButton();
            
       } 
       }
        if(r3status>=4){
            if(c.equals(i) && i.equals(o) && o.equals(u)){
            jLabel3.setText("Player" +turn+ "Won");
                        DisableButton();
            
        } 
       else if(i.equals(o)&& o.equals(u)&& u.equals(g5_b3)){
            jLabel3.setText("Player" +turn+ "Won");
                        DisableButton();
            
       } 
    } 
         if(r4status>=4){
       if(d.equals(j)&& j.equals(p)&& p.equals(v)){
            jLabel3.setText("Player" +turn+ "Won");
                        DisableButton();
            
        } 
       else if(j.equals(p)&& p.equals(v)&& v.equals(g5_b4)){
            jLabel3.setText("Player" +turn+ "Won");
                        DisableButton();
            
       } 
    } 
          if(r5status>=4){
       if(e.equals(k)&& k.equals(q)&& q.equals(w)){
            jLabel3.setText("Player" +turn+ "Won");
                        DisableButton();
            
        } 
       else if(k.equals(q)&& q.equals(w)&& w.equals(g5_b5)){
            jLabel3.setText("Player" +turn+ "Won");
                        DisableButton();
            
       } 
    } 
           if(r6status>=4){
       if(f.equals(l)&& l.equals(r)&& r.equals(x)){
            jLabel3.setText("Player" +turn+ "Won");
                        DisableButton();
            
        } 
       else if(l.equals(r)&& r.equals(x)&& x.equals(g5_b6)){
            jLabel3.setText("Player" +turn+ "Won");
                        DisableButton();
            
            
       } 
    } 
   
  }   
  
  //vertically
   public void checkwin(){
    
      //group1:
    String a=g1b1.getBackground().toString();
    String b=g1b2.getBackground().toString();
    String c=g1b3.getBackground().toString();
    String d=g1b4.getBackground().toString();
    String e=g1b5.getBackground().toString();
    String f=g1b6.getBackground().toString();
    
    //group 2
    String g=g2b1.getBackground().toString();
    String h=g2b2.getBackground().toString();
    String i=g2b3.getBackground().toString();
    String j=g2b4.getBackground().toString();
    String k=g2b5.getBackground().toString();
    String l=g2b6.getBackground().toString();
    
    //group 3
    String m=g3b1.getBackground().toString();
    String n=g3b2.getBackground().toString();
    String o=g3b3.getBackground().toString();
    String p=g3b4.getBackground().toString();
    String q=g3b5.getBackground().toString();
    String r=g3b6.getBackground().toString();
    
    //group 4
    String s=g4b1.getBackground().toString();
    String t=g4b2.getBackground().toString();
    String u=g4b3.getBackground().toString();
    String v=g4b4.getBackground().toString();
    String w=g4b5.getBackground().toString();
    String x=g4b6.getBackground().toString();
    
    //group 5
    String y=g5b1.getBackground().toString();
    String z=g5b2.getBackground().toString();
    String g5_b3=g5b3.getBackground().toString(); 
    String g5_b4=g5b4.getBackground().toString(); 
    String g5_b5=g5b5.getBackground().toString(); 
    String g5_b6=g5b6.getBackground().toString(); 
    
    
     if (g1status >=4 ) {
    if(a.equals(b) && b.equals(c) && c.equals(d)){
         jLabel3.setText("Player" +turn+ "Won");
                     DisableButton();
            

    }
    else if(b.equals(c) && c.equals(d) && d.equals(e)){
        jLabel3.setText("Player" +turn+ "Won");
                    DisableButton();
            
    }
    else if(c.equals(d) && d.equals(e) && e.equals(f)){
        jLabel3.setText("Player" +turn+ "Won");
                    DisableButton();
            
    }

     }
      if(g2status>=4){
        if(g.equals(h)&&h.equals(i)&&i.equals(j)){
             jLabel3.setText("Player" +turn+ "Won");
                         DisableButton();
            
        }
        else if(h.equals(i) && i.equals(j) && j.equals(k)){
         jLabel3.setText("Player" +turn+ "Won");
                     DisableButton();
            
    }
        else if(i.equals(j) && j.equals(k) && k.equals(l)){
         jLabel3.setText("Player" +turn+ "Won");
                     DisableButton();
            
    }
     }
      if(g3status>=4){
         if(m.equals(n)&& n.equals(o) && o.equals(p)){
            jLabel3.setText("Player" +turn+ "Won");
                        DisableButton();
            
        }
          else if(n.equals(o) && o.equals(p) && p.equals(q)){
         jLabel3.setText("Player" +turn+ "Won");
                     DisableButton();
            
     }
          else if(o.equals(p) && p.equals(q) && q.equals(r)){
        jLabel3.setText("Player" +turn+ "Won");
                    DisableButton();
            
          }}
       if(g4status>=4){
          if(s.equals(t)&& t.equals(u) && u.equals(v)){
            jLabel3.setText("Player" +turn+ "Won");
                        DisableButton();
            
        }
          else if(t.equals(u) && u.equals(v) && v.equals(w)){
        jLabel3.setText("Player" +turn+ "Won");
                    DisableButton();
            
     }
          else if(u.equals(v) && v.equals(w) && w.equals(x)){
         jLabel3.setText("Player" +turn+ "Won");
                     DisableButton();
            
     }}
      if(g5status>=4){
         if(y.equals(z)&& z.equals(g5_b3) && g5_b3.equals(g5_b4)){
            jLabel3.setText("Player" +turn+ "Won");
                        DisableButton();
            
        }
          else if(z.equals(g5_b3) && g5_b3.equals(g5_b4) && g5_b4.equals(g5_b5)){
        jLabel3.setText("Player" +turn+ "Won");
                    DisableButton();
            
     }
          else if(g5_b3.equals(g5_b4) && g5_b4.equals(g5_b5) && g5_b5.equals(g5_b6)){
        jLabel3.setText("Player" +turn+ "Won");
                    DisableButton();
            
     } }
     
    }
   public void checkWinDiagonal(){
       String a=g1b1.getBackground().toString();
    String b=g1b2.getBackground().toString();
    String c=g1b3.getBackground().toString();
    String d=g1b4.getBackground().toString();
    String e=g1b5.getBackground().toString();
    String f=g1b6.getBackground().toString();
    
    //group 2
    String g=g2b1.getBackground().toString();
    String h=g2b2.getBackground().toString();
    String i=g2b3.getBackground().toString();
    String j=g2b4.getBackground().toString();
    String k=g2b5.getBackground().toString();
    String l=g2b6.getBackground().toString();
    
    //group 3
    String m=g3b1.getBackground().toString();
    String n=g3b2.getBackground().toString();
    String o=g3b3.getBackground().toString();
    String p=g3b4.getBackground().toString();
    String q=g3b5.getBackground().toString();
    String r=g3b6.getBackground().toString();
    
    //group 4
    String s=g4b1.getBackground().toString();
    String t=g4b2.getBackground().toString();
    String u=g4b3.getBackground().toString();
    String v=g4b4.getBackground().toString();
    String w=g4b5.getBackground().toString();
    String x=g4b6.getBackground().toString();
    
    //group 5
    String y=g5b1.getBackground().toString();
    String z=g5b2.getBackground().toString();
    String g5_b3=g5b3.getBackground().toString(); //31
    String g5_b4=g5b4.getBackground().toString(); //32
    String g5_b5=g5b5.getBackground().toString(); //33
    String g5_b6=g5b6.getBackground().toString(); //34
    
     if (d1status >=4 ) {
    if(a.equals(h) && h.equals(o) && o.equals(v)){
        jLabel3.setText("Player" +turn+ "Won");
                    DisableButton();
            
        
    }
    else if(h.equals(o) && o.equals(v) && v.equals(g5_b5)){
        jLabel3.setText("Player" +turn+ "Won");
                    DisableButton();
            
         
    }
    
}
     if(d2status>=4){
             if(b.equals(i) && i.equals(p) && p.equals(w)){
        jLabel3.setText("Player" +turn+ "Won");
                    DisableButton();
            
        
    }
    else if(i.equals(p) && p.equals(w) && w.equals(g5_b6)){
       jLabel3.setText("Player" +turn+ "Won");
                   DisableButton();
            
         
    }
 }
      if(d3status>=4){
             if(c.equals(j) && j.equals(q) && q.equals(x)){
        jLabel3.setText("Player" +turn+ "Won");
                    DisableButton();
            
        
    }
   
 }
      if(d4status>=4){
             if(g.equals(n) && n.equals(u) && u.equals(g5_b5)){
       jLabel3.setText("Player" +turn+ "Won");
                   DisableButton();
            
        
    }
   
 }
     if(d5status>=4){
             if(f.equals(k) && k.equals(p) && p.equals(u)){
        jLabel3.setText("Player" +turn+ "Won");
                    DisableButton();
            
        
    }
    else if(k.equals(p) && p.equals(u) && u.equals(z)){
        jLabel3.setText("Player" +turn+ "Won");
                    DisableButton();
            
         
    }
 }
     if(d6status>=4){
             if(e.equals(j) && j.equals(o) && o.equals(t)){
        jLabel3.setText("Player" +turn+ "Won");
                    DisableButton();
            
        
    }
    else if(j.equals(o) && o.equals(t) && t.equals(y)){
       jLabel3.setText("Player" +turn+ "Won");
                   DisableButton();
            
         
    }
 }
     if(d7status>=4){
             if(d.equals(i) && i.equals(n) && n.equals(s)){
        jLabel3.setText("Player" +turn+ "Won");
                    DisableButton();
            
        
    }
   
 }
     if(d8status>=4){
             if(l.equals(q) && q.equals(v) && v.equals(g5_b3)){
       jLabel3.setText("Player" +turn+ "Won");
                   DisableButton();
            
       
    }
   
 }
   }
   
   public void DisableButton(){
       //group1:
        g1b1.setEnabled(false);
        g1b2.setEnabled(false);
    g1b3.setEnabled(false);
    g1b4.setEnabled(false);
    g1b5.setEnabled(false);
    g1b6.setEnabled(false);
    
    //group2:
    g2b1.setEnabled(false);
    g2b2.setEnabled(false);
    g2b3.setEnabled(false);
    g2b4.setEnabled(false);
    g2b5.setEnabled(false);
    g2b6.setEnabled(false);
    
    //group3:
    g3b1.setEnabled(false);
    g3b2.setEnabled(false);
    g3b3.setEnabled(false);
    g3b4.setEnabled(false);
    g3b5.setEnabled(false);
    g3b6.setEnabled(false);
    
    //group4:
    g4b1.setEnabled(false);
    g4b2.setEnabled(false);
    g4b3.setEnabled(false);
    g4b4.setEnabled(false);
    g4b5.setEnabled(false);
    g4b6.setEnabled(false);
    
    //group5:
    g5b1.setEnabled(false);
    g5b2.setEnabled(false);
    g5b3.setEnabled(false);
    g5b4.setEnabled(false);
    g5b5.setEnabled(false);
    g5b6.setEnabled(false);

   }
   
   
   


  
   
   public void resetGame() {
    // Reset all status variables to 0
    g1status = 1;
    g2status = 1;
    g3status = 1;
    g4status = 1;
    g5status = 1;
    g6status = 1;
    r1status = 1;
    r2status = 1;
    r3status = 1;
    r4status = 1;
    r5status = 1;
    r6status = 1;
    d1status = 1;
    d2status = 1;
    d3status = 1;
    d4status = 1;
    d5status = 1;
    d6status = 1;
    d7status = 1;
    d8status = 1;

    g1b1.setBackground(null);
    g1b2.setBackground(null);
    g1b3.setBackground(null);
    g1b4.setBackground(null);
    g1b5.setBackground(null);
    g1b6.setBackground(null);
    g2b1.setBackground(null);
    g2b2.setBackground(null);
    g2b3.setBackground(null);
    g2b4.setBackground(null);
    g2b5.setBackground(null);
    g2b6.setBackground(null);
    g3b1.setBackground(null);
    g3b2.setBackground(null);
    g3b3.setBackground(null);
    g3b4.setBackground(null);
    g3b5.setBackground(null);
    g3b6.setBackground(null);
    g4b1.setBackground(null);
    g4b2.setBackground(null);
    g4b3.setBackground(null);
    g4b4.setBackground(null);
    g4b5.setBackground(null);
    g4b6.setBackground(null);
    g5b1.setBackground(null);
    g5b2.setBackground(null);
    g5b3.setBackground(null);
    g5b4.setBackground(null);
    g5b5.setBackground(null);
    g5b6.setBackground(null);
    g1b1.setEnabled(true);
    g1b2.setEnabled(true);
    g1b3.setEnabled(true);
    g1b4.setEnabled(true);
    g1b5.setEnabled(true);
    g1b6.setEnabled(true);
    g2b1.setEnabled(true);
    g2b2.setEnabled(true);
    g2b3.setEnabled(true);
    g2b4.setEnabled(true);
    g2b5.setEnabled(true);
    g2b6.setEnabled(true);
    g3b1.setEnabled(true);
    g3b2.setEnabled(true);
    g3b3.setEnabled(true);
    g3b4.setEnabled(true);
    g3b5.setEnabled(true);
    g3b6.setEnabled(true);
    g4b1.setEnabled(true);
    g4b2.setEnabled(true);
    g4b3.setEnabled(true);
    g4b4.setEnabled(true);
    g4b5.setEnabled(true);
    g4b6.setEnabled(true);
    g5b1.setEnabled(true);
    g5b2.setEnabled(true);
    g5b3.setEnabled(true);
    g5b4.setEnabled(true);
    g5b5.setEnabled(true);
    g5b6.setEnabled(true);

    // Reset the status label
    jLabel3.setText("");

    // Reset the turn label
    turn = 1;
    jLabel1.setText("Player 1 Turn");
    
}

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        g1b6 = new javax.swing.JButton();
        g2b6 = new javax.swing.JButton();
        g3b6 = new javax.swing.JButton();
        g4b6 = new javax.swing.JButton();
        g5b6 = new javax.swing.JButton();
        g1b5 = new javax.swing.JButton();
        g2b5 = new javax.swing.JButton();
        g3b5 = new javax.swing.JButton();
        g4b5 = new javax.swing.JButton();
        g5b5 = new javax.swing.JButton();
        g3b4 = new javax.swing.JButton();
        g4b4 = new javax.swing.JButton();
        g5b4 = new javax.swing.JButton();
        g1b4 = new javax.swing.JButton();
        g2b4 = new javax.swing.JButton();
        g2b3 = new javax.swing.JButton();
        g3b3 = new javax.swing.JButton();
        g4b3 = new javax.swing.JButton();
        g5b3 = new javax.swing.JButton();
        g1b3 = new javax.swing.JButton();
        g3b2 = new javax.swing.JButton();
        g4b2 = new javax.swing.JButton();
        g5b2 = new javax.swing.JButton();
        g2b2 = new javax.swing.JButton();
        g1b2 = new javax.swing.JButton();
        g3b1 = new javax.swing.JButton();
        g4b1 = new javax.swing.JButton();
        g5b1 = new javax.swing.JButton();
        g1b1 = new javax.swing.JButton();
        g2b1 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N

        g1b6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                g1b6MouseClicked(evt);
            }
        });

        g2b6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                g2b6MouseClicked(evt);
            }
        });

        g3b6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                g3b6MouseClicked(evt);
            }
        });

        g4b6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                g4b6MouseClicked(evt);
            }
        });

        g5b6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                g5b6MouseClicked(evt);
            }
        });

        g1b5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                g1b5MouseClicked(evt);
            }
        });

        g2b5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                g2b5MouseClicked(evt);
            }
        });

        g3b5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                g3b5MouseClicked(evt);
            }
        });

        g4b5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                g4b5MouseClicked(evt);
            }
        });

        g5b5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                g5b5MouseClicked(evt);
            }
        });

        g3b4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                g3b4MouseClicked(evt);
            }
        });

        g4b4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                g4b4MouseClicked(evt);
            }
        });

        g5b4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                g5b4MouseClicked(evt);
            }
        });

        g1b4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                g1b4MouseClicked(evt);
            }
        });
        g1b4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                g1b4ActionPerformed(evt);
            }
        });

        g2b4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                g2b4MouseClicked(evt);
            }
        });

        g2b3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                g2b3MouseClicked(evt);
            }
        });

        g3b3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                g3b3MouseClicked(evt);
            }
        });

        g4b3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                g4b3MouseClicked(evt);
            }
        });
        g4b3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                g4b3ActionPerformed(evt);
            }
        });

        g5b3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                g5b3MouseClicked(evt);
            }
        });

        g1b3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                g1b3MouseClicked(evt);
            }
        });
        g1b3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                g1b3ActionPerformed(evt);
            }
        });

        g3b2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                g3b2MouseClicked(evt);
            }
        });

        g4b2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                g4b2MouseClicked(evt);
            }
        });
        g4b2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                g4b2ActionPerformed(evt);
            }
        });

        g5b2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                g5b2MouseClicked(evt);
            }
        });

        g2b2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                g2b2MouseClicked(evt);
            }
        });

        g1b2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                g1b2MouseClicked(evt);
            }
        });

        g3b1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                g3b1MouseClicked(evt);
            }
        });
        g3b1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                g3b1ActionPerformed(evt);
            }
        });

        g4b1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                g4b1MouseClicked(evt);
            }
        });

        g5b1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                g5b1MouseClicked(evt);
            }
        });

        g1b1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                g1b1MouseClicked(evt);
            }
        });
        g1b1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                g1b1ActionPerformed(evt);
            }
        });

        g2b1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                g2b1MouseClicked(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel2.setText("Connect4 Game");

        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton1.setText("Clear");
        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton1MouseClicked(evt);
            }
        });
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(g1b1, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(g1b2, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(g2b2, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(g3b2, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(g4b2, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(g5b2, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(g2b1, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addComponent(g3b1, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(g4b1, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(g5b1, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(g1b5, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(g2b5, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(g3b5, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(g4b5, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(g5b5, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(g1b4, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(g2b4, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(g3b4, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(g4b4, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(g5b4, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(g1b3, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(g2b3, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(g3b3, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(g4b3, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(g5b3, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(22, 22, 22)
                                .addComponent(jButton1)
                                .addGap(314, 314, 314)
                                .addComponent(jLabel3))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(g1b6, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(g2b6, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(g3b6, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(g4b6, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(g5b6, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(67, 67, 67)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 265, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(230, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jButton1)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(50, 50, 50)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(g1b6, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(g2b6, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(g3b6, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(g4b6, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(g5b6, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(g1b5, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(g2b5, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(g3b5, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(g4b5, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(g5b5, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(g1b4, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(g2b4, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(g3b4, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(g4b4, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(g5b4, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(g1b3, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(g2b3, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(g3b3, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(g4b3, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(g5b3, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(g1b2, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(g2b2, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(g3b2, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(g4b2, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(g5b2, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(g5b1, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(g4b1, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(g3b1, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(g1b1, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(g2b1, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3))))
                .addContainerGap(35, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void g1b1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_g1b1MouseClicked
        if(groupcheck(1)==1){
          if(turn==1)
              g1b1.setBackground(Color.red);
          else
              g1b1.setBackground(Color.yellow);
       
       checkwin();
       checkWinRow();
       checkWinDiagonal();
       switchturn();
          g1status++;
          r1status++;
          d1status++;

      } 
      
    }//GEN-LAST:event_g1b1MouseClicked

    private void g2b1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_g2b1MouseClicked
       if(groupcheck(2)==1){
         if(turn==1) 
             g2b1.setBackground(Color.red);
         else
             g2b1.setBackground(Color.yellow);
         
         checkwin();
                   checkWinRow();
          checkWinDiagonal();
          switchturn();
        g2status++;
        r1status++;
        d4status++;
        
      }
    }//GEN-LAST:event_g2b1MouseClicked

    private void g3b1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_g3b1MouseClicked
        if(groupcheck(3)==1){
         if(turn==1)
             g3b1.setBackground(Color.red);
         else
             g3b1.setBackground(Color.yellow); 
         
        checkwin();
         checkWinRow();
        switchturn();
        g3status++;
        r1status++;
      }
       
    }//GEN-LAST:event_g3b1MouseClicked

    private void g4b1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_g4b1MouseClicked
       if(groupcheck(4)==1){
         if(turn==1)  g4b1.setBackground(Color.red);
         else g4b1.setBackground(Color.yellow);
          checkwin();
           checkWinRow();
          checkWinDiagonal();
          switchturn();
        g4status++;
        r1status++;
        d7status++;

      }
    }//GEN-LAST:event_g4b1MouseClicked

    private void g1b2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_g1b2MouseClicked
       if(groupcheck(1)==2){
         if(turn==1) 
             g1b2.setBackground(Color.red);
         else 
             g1b2.setBackground(Color.yellow);;
         checkwin();
         checkWinRow();
         checkWinDiagonal();
         switchturn();
        g1status++;
        r2status++;
        d2status++;
      }
    }//GEN-LAST:event_g1b2MouseClicked

    private void g2b2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_g2b2MouseClicked
              if(groupcheck(2)==2){
         if(turn==1) 
             g2b2.setBackground(Color.red);
         else
             g2b2.setBackground(Color.yellow);
         checkwin();
         checkWinRow();
          checkWinDiagonal();
          switchturn();
        g2status++;
         r2status++;
            d1status++;

    }//GEN-LAST:event_g2b2MouseClicked
    }
    private void g3b2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_g3b2MouseClicked

        
       if(groupcheck(3)==2){
         if(turn==1)  g3b2.setBackground(Color.red);
         else g3b2.setBackground(Color.yellow);
           checkwin();
           checkWinRow();
          checkWinDiagonal();  
          switchturn();
        g3status++;
        r2status++;
        d4status++;
        d7status++;

      }
    }//GEN-LAST:event_g3b2MouseClicked

    private void g5b1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_g5b1MouseClicked
              if(groupcheck(5)==1){
         if(turn==1) 
             g5b1.setBackground(Color.red);
         else
             g5b1.setBackground(Color.yellow);
        checkwin();
        checkWinRow();
          checkWinDiagonal();
          switchturn();
        g5status++;
        r1status++;
        d6status++;

      }
    }//GEN-LAST:event_g5b1MouseClicked

    private void g4b2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_g4b2MouseClicked
       if(groupcheck(4)==2){
         if(turn==1)  
             g4b2.setBackground(Color.red);
         else
             g4b2.setBackground(Color.yellow);
       
       checkwin();
       checkWinRow();
          checkWinDiagonal();
          switchturn();
        g4status++;
         r2status++;
         d6status++;

       
      }
    }//GEN-LAST:event_g4b2MouseClicked

    private void g5b2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_g5b2MouseClicked
    if(groupcheck(5)==2){
         if(turn==1)
             g5b2.setBackground(Color.red);
         else
             g5b2.setBackground(Color.yellow);
         
         checkwin();
         checkWinRow();
           checkWinDiagonal();
           switchturn();
        g5status++;
         r2status++;
         d5status++;

     }
    }//GEN-LAST:event_g5b2MouseClicked

    private void g1b3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_g1b3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_g1b3ActionPerformed

    private void g4b2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_g4b2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_g4b2ActionPerformed

    private void g1b1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_g1b1ActionPerformed
     
    }//GEN-LAST:event_g1b1ActionPerformed

    private void g3b1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_g3b1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_g3b1ActionPerformed

    private void g1b3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_g1b3MouseClicked
        if(groupcheck(1)==3){
         if(turn==1) 
             g1b3.setBackground(Color.red);
         else
             g1b3.setBackground(Color.yellow);
        
         checkwin();
         checkWinRow();
         checkWinDiagonal();
         switchturn();
         g1status++;
         d3status++;
        r3status++;         
        }
    }//GEN-LAST:event_g1b3MouseClicked

    private void g1b4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_g1b4ActionPerformed
        if(groupcheck(1)==4){
         if(turn==1)
             g1b4.setBackground(Color.red);
         else
             g1b4.setBackground(Color.yellow);
        
         checkwin();
         checkWinRow();
           checkWinDiagonal();
           switchturn();
        g1status++;
        d7status++;
        r4status++;

      }
    }//GEN-LAST:event_g1b4ActionPerformed

    private void g1b5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_g1b5MouseClicked
        if(groupcheck(1)==5){
         if(turn==1) 
             g1b5.setBackground(Color.red);
         else
             g1b5.setBackground(Color.yellow);
        
          checkwin();
          checkWinRow();
         checkWinDiagonal();  
         switchturn();
        g1status++;
        d6status++;
        r5status++;

      }
    }//GEN-LAST:event_g1b5MouseClicked

    private void g2b3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_g2b3MouseClicked
        if(groupcheck(2)==3){
         if(turn==1) 
             g2b3.setBackground(Color.red);
         else
             g2b3.setBackground(Color.yellow);
         
         checkwin();
                   checkWinRow();
          checkWinDiagonal();
          switchturn();
        g2status++;
        d2status++;
        d7status++;
        r3status++;

        }                 
    }//GEN-LAST:event_g2b3MouseClicked

    private void g2b4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_g2b4MouseClicked
        if(groupcheck(2)==4){
         if(turn==1)  g2b4.setBackground(Color.red);
         else g2b4.setBackground(Color.yellow);
      
         checkwin(); 
         checkWinRow();
          checkWinDiagonal();
          switchturn();
        g2status++;
         d3status++;
         d6status++;
         r4status++;
        }                 
    }//GEN-LAST:event_g2b4MouseClicked

    private void g2b5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_g2b5MouseClicked
        if(groupcheck(2)==5){
         if(turn==1)
             g2b5.setBackground(Color.red);
         else 
             g2b5.setBackground(Color.yellow);
         
         checkwin();
         checkWinRow();
          checkWinDiagonal();
          switchturn();
        g2status++;
        d5status++;
        r5status++;
    }                 
    }//GEN-LAST:event_g2b5MouseClicked

    private void g2b6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_g2b6MouseClicked
         if(groupcheck(2)==6){
         if(turn==1)  
             g2b6.setBackground(Color.red);
         else 
             g2b6.setBackground(Color.yellow);
        
          checkwin();
          checkWinRow();
          checkWinDiagonal();
          switchturn();
        g2status++;
        d8status++;
        r6status++;
    }                 
    }//GEN-LAST:event_g2b6MouseClicked

    private void g1b4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_g1b4MouseClicked
        if(groupcheck(1)==4){
         if(turn==1)  g1b4.setBackground(Color.red);
         else g1b4.setBackground(Color.yellow);
        
         checkwin();
         checkWinRow();
           checkWinDiagonal();
           switchturn();
        g1status++;
        d7status++;
        r4status++;

      }
    }//GEN-LAST:event_g1b4MouseClicked

    private void g1b6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_g1b6MouseClicked
    if(groupcheck(1)==6){
         if(turn==1) 
             g1b6.setBackground(Color.red);
         else
             g1b6.setBackground(Color.yellow);
       
          checkwin();
                    checkWinDiagonal();
          checkWinRow();
          switchturn();
        g1status++;
        d5status++;
        r6status++;

      }
    }//GEN-LAST:event_g1b6MouseClicked

    private void g3b3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_g3b3MouseClicked
       if(groupcheck(3)==3){
         if(turn==1)  g3b3.setBackground(Color.red);
         else g3b3.setBackground(Color.yellow);
         
         checkwin();
         checkWinRow();
          checkWinDiagonal();
          switchturn();
        g3status++;
            d1status++;
            d6status++;
            r3status++;

      }
    }//GEN-LAST:event_g3b3MouseClicked

    private void g3b4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_g3b4MouseClicked
        if(groupcheck(3)==4){
         if(turn==1) 
             g3b4.setBackground(Color.red);
         else 
             g3b4.setBackground(Color.yellow);
         
          checkwin();
          checkWinRow();
          checkWinDiagonal();
          switchturn();
        g3status++;
        d2status++;
        d5status++;
        r4status++;

      }
    }//GEN-LAST:event_g3b4MouseClicked

    private void g3b5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_g3b5MouseClicked
           if(groupcheck(3)==5){
         if(turn==1)  g3b5.setBackground(Color.red);
         else g3b5.setBackground(Color.yellow);
        
         checkwin();
                   checkWinRow();
          checkWinDiagonal();
          switchturn();
        g3status++;
         d3status++;
         d8status++;
         r5status++;
      }
    }//GEN-LAST:event_g3b5MouseClicked

    private void g3b6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_g3b6MouseClicked
           if(groupcheck(3)==6){
         if(turn==1)  
             g3b6.setBackground(Color.red);
         else 
             g3b6.setBackground(Color.yellow);
      
         checkwin();
         checkWinRow();
         switchturn();
        g3status++;
        r6status++;
      }
    }//GEN-LAST:event_g3b6MouseClicked

    private void g4b3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_g4b3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_g4b3ActionPerformed

    private void g4b3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_g4b3MouseClicked
   if(groupcheck(4)==3){
         if(turn==1) 
             g4b3.setBackground(Color.red);
         else
             g4b3.setBackground(Color.yellow);
        
           checkwin();
          checkWinRow();
          checkWinDiagonal();
          switchturn();
        g4status++;
         d4status++;
         d5status++;
         r3status++;

      }        
    }//GEN-LAST:event_g4b3MouseClicked

    private void g4b4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_g4b4MouseClicked
         if(groupcheck(4)==4){
         if(turn==1)
             g4b4.setBackground(Color.red);
         else
             g4b4.setBackground(Color.yellow);
        
         checkwin();
         checkWinRow();
          checkWinDiagonal();
          switchturn();
        g4status++;
            d1status++;
            d8status++;
            r4status++;

      }  
    }//GEN-LAST:event_g4b4MouseClicked

    private void g4b5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_g4b5MouseClicked
          if(groupcheck(4)==5){
         if(turn==1)
             g4b5.setBackground(Color.red);
         else
             g4b5.setBackground(Color.yellow);
        
         checkwin();
         checkWinRow();
          checkWinDiagonal();
          switchturn();
        g4status++;
        d2status++;
        r5status++;

      }  
    }//GEN-LAST:event_g4b5MouseClicked

    private void g4b6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_g4b6MouseClicked
         if(groupcheck(4)==6){
         if(turn==1)
             g4b6.setBackground(Color.red);
         else 
             g4b6.setBackground(Color.yellow);
        
         checkwin();
         checkWinRow();
          checkWinDiagonal();
          switchturn();
           g4status++;
          d3status++;
        r6status++;
      }  
    }//GEN-LAST:event_g4b6MouseClicked

    private void g5b3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_g5b3MouseClicked
                    if(groupcheck(5)==3){
         if(turn==1) 
             g5b3.setBackground(Color.red);
         else
             g5b3.setBackground(Color.yellow);
        
         checkwin();
         checkWinRow();
          checkWinDiagonal();
          switchturn();
        g5status++;
        d8status++;
        r3status++;
      }
    }//GEN-LAST:event_g5b3MouseClicked

    private void g5b4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_g5b4MouseClicked
          if(groupcheck(5)==4){
         if(turn==1) 
             g5b4.setBackground(Color.red);
         else 
             g5b4.setBackground(Color.yellow);
      
         checkwin();
           checkwin();
          checkWinRow();
          switchturn();
        g5status++;
        r4status++;

      }
    }//GEN-LAST:event_g5b4MouseClicked

    private void g5b5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_g5b5MouseClicked
        if(groupcheck(5)==5){
         if(turn==1) 
             g5b5.setBackground(Color.red);
         else
             g5b5.setBackground(Color.yellow);
        
         checkwin();
         checkWinRow();
          checkWinDiagonal();
          switchturn();
        g5status++;
         d1status++;
        d4status++;
        r5status++;
      }
    }//GEN-LAST:event_g5b5MouseClicked

    private void g5b6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_g5b6MouseClicked
         if(groupcheck(5)==6){
         if(turn==1)
             g5b6.setBackground(Color.red);
         else
             g5b6.setBackground(Color.yellow);
        
         checkwin();
         checkWinRow();
          checkWinDiagonal();
          switchturn();
        g5status++;
        d2status++;
        r6status++;

      }
    }//GEN-LAST:event_g5b6MouseClicked

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1MouseClicked
resetGame();        
    }//GEN-LAST:event_jButton1MouseClicked



    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(connectt4.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(connectt4.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(connectt4.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(connectt4.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new connectt4().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton g1b1;
    private javax.swing.JButton g1b2;
    private javax.swing.JButton g1b3;
    private javax.swing.JButton g1b4;
    private javax.swing.JButton g1b5;
    private javax.swing.JButton g1b6;
    private javax.swing.JButton g2b1;
    private javax.swing.JButton g2b2;
    private javax.swing.JButton g2b3;
    private javax.swing.JButton g2b4;
    private javax.swing.JButton g2b5;
    private javax.swing.JButton g2b6;
    private javax.swing.JButton g3b1;
    private javax.swing.JButton g3b2;
    private javax.swing.JButton g3b3;
    private javax.swing.JButton g3b4;
    private javax.swing.JButton g3b5;
    private javax.swing.JButton g3b6;
    private javax.swing.JButton g4b1;
    private javax.swing.JButton g4b2;
    private javax.swing.JButton g4b3;
    private javax.swing.JButton g4b4;
    private javax.swing.JButton g4b5;
    private javax.swing.JButton g4b6;
    private javax.swing.JButton g5b1;
    private javax.swing.JButton g5b2;
    private javax.swing.JButton g5b3;
    private javax.swing.JButton g5b4;
    private javax.swing.JButton g5b5;
    private javax.swing.JButton g5b6;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
